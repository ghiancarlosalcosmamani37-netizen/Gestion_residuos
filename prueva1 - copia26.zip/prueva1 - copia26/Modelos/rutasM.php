<?php //  Modelos/rutasM.php
class RutasM{
    public function procesaRutasM($ruta){
        if( $ruta == "ingreso" || 
            $ruta == 'empleados' || 
            $ruta == 'registrar' || 
            $ruta == 'salir' ||
            $ruta == 'editar' ||
            $ruta == 'editarU' ||
            $ruta == 'usuario' || 
            $ruta == 'nooperativo' || // <-- No uso ruta añadida aquí
            $ruta == 'Filtrar' || // <-- No uso ruta añadida aquí
            $ruta == 'Favoritos' || // <-- No uso ruta añadida aquí
            $ruta == 'Buscar' ||// <-- No uso ruta añadida aquí
            $ruta == 'verificar' || 
            $ruta == 'Archivados' || // <-- No uso ruta añadida aquí
            $ruta == 'cambiarcontraseña' ||
            $ruta == 'recuperar' ||
            $ruta == 'crearcampania' || // <-- Nueva ruta añadida aquí
            $ruta == 'campanias' || // <-- Nueva ruta añadida aquí
            $ruta == 'reciclaje' || // <-- Nueva ruta añadida aquí
            
            $ruta == 'crearusuario')
        {
            $pagina = "Vistas/modulos/".$ruta. ".php";
        }
        else if($ruta == 'index'){
            $pagina = "Vistas/modulos/ingreso.php";
        }
        else {
            $pagina = "Vistas/modulos/ingreso.php";
        }
        return $pagina;
    }

}
?>