<?php  //Modelos/empleadosM.php
require_once "conexionBD.php";

class EmpleadosM extends ConexionBD
{
    // Insertar un nuevo sector
    public function registrarSectorM($datosC, $tablaBD = 'sectores')
    {
        $cbd = ConexionBD::cBD();
        $nombre = mysql_entities_fix_string($cbd, $datosC['nombre_sector']);
        $user = $_SESSION['username'];

        $query = "INSERT INTO $tablaBD (nombre_sector, creado_por) VALUES ('$nombre', '$user')";
        return $cbd->query($query);
    }

    // Listar todos los sectores ordenados alfabéticamente
    public function mostrarSectoresM($tablaBD = 'sectores')
    {
        $cbd = ConexionBD::cBD();
        $query = "SELECT * FROM $tablaBD ORDER BY nombre_sector ASC";
        return $cbd->query($query);
    }

    // 1. Modificar función de Inserción
    public function registrarReciclajeDiarioM($datosC, $tablaBD = 'registro_reciclaje')
    {
        $cbd = ConexionBD::cBD();
        $id_sector = mysql_entities_fix_string($cbd, $datosC['id_sector']);
        $kg = mysql_entities_fix_string($cbd, $datosC['cantidad_kg']);
        $placa = mysql_entities_fix_string($cbd, $datosC['placa_vehiculo']); // <-- Escapa la Placa
        $fecha = mysql_entities_fix_string($cbd, $datosC['fecha']);
        $user = $_SESSION['username'];

        $query = "INSERT INTO $tablaBD (id_sector, cantidad_kg, placa_vehiculo, fecha, registrado_por) 
                  VALUES ('$id_sector', '$kg', '$placa', '$fecha', '$user')";
        return $cbd->query($query);
    }

    // Consultar el historial vinculando las tablas con un JOIN para ver el nombre del sector
    // 2. Modificar función de Consulta para traer la placa en el historial
    public function mostrarHistorialReciclajeM()
    {
        $cbd = ConexionBD::cBD();
        // Agregamos r.placa_vehiculo a la consulta SELECT
        $query = "SELECT r.id_registro, s.nombre_sector, r.cantidad_kg, r.placa_vehiculo, r.fecha, r.registrado_por 
                  FROM registro_reciclaje r 
                  INNER JOIN sectores s ON r.id_sector = s.id_sector 
                  ORDER BY r.fecha DESC, r.id_registro DESC";
        return $cbd->query($query);
    }

    // Obtener la lista unificada de asistentes para exportar a Word
    public function mostrarAsistentesCampaniaM($id_campania)
    {
        $cbd = ConexionBD::cBD();
        $id = $cbd->real_escape_string($id_campania);

        // Combinamos ambas tablas igualando el número de columnas devueltas
        $query = "SELECT nombres, sexo, dni, telefono, 'Ciudadano' AS tipo, 'No aplica' AS institucion 
                  FROM ficha_sensibilizacion_ciudadana 
                  WHERE id_campania = '$id'
                  UNION ALL
                  SELECT nombres, sexo, dni, telefono, 'Institución' AS tipo, nombre_institucion AS institucion 
                  FROM ficha_sensibilizacion_institucion 
                  WHERE id_campania = '$id'";

        return $cbd->query($query);
    }


    // Trae campañas cuya fecha es hoy o futura
    public function mostrarCampaniasActivasM($tablaBD = 'campanias')
    {
        $cbd = ConexionBD::cBD();
        $query = "SELECT id_campania, nombre_campania, fecha, lugar, tipo_reunion, creado_por 
                  FROM $tablaBD 
                  WHERE fecha >= CURDATE() 
                  ORDER BY fecha ASC";
        $result = $cbd->query($query);
        return $result;
    }

    // Trae campañas cuya fecha ya pasó (antiguas)
    public function mostrarCampaniasAntiguasM($tablaBD = 'campanias')
    {
        $cbd = ConexionBD::cBD();
        $query = "SELECT id_campania, nombre_campania, fecha, lugar, tipo_reunion, creado_por 
                  FROM $tablaBD 
                  WHERE fecha < CURDATE() 
                  ORDER BY fecha DESC";
        $result = $cbd->query($query);
        return $result;
    }

    public function registrarCampaniaM($datosC, $tablaBD = 'campanias')
    {
        $cbd = ConexionBD::cBD();

        // Obtener el usuario administrador actual
        $query1 = "SELECT username FROM usuario WHERE username='$_SESSION[username]'";
        $result1 = $cbd->query($query1);
        $row1 = $result1->fetch_array(MYSQLI_NUM);
        $creado_por = $row1[0];

        $nombre_campania = mysql_entities_fix_string($cbd, $datosC['nombre_campania']);
        $fecha = mysql_entities_fix_string($cbd, $datosC['fecha']);
        $lugar = mysql_entities_fix_string($cbd, $datosC['lugar']);
        $tipo_reunion = mysql_entities_fix_string($cbd, $datosC['tipo_reunion']);

        $query = "INSERT INTO $tablaBD (nombre_campania, fecha, lugar, tipo_reunion, creado_por) 
                  VALUES ('$nombre_campania', '$fecha', '$lugar', '$tipo_reunion', '$creado_por')";

        return $cbd->query($query);
    }

    public function registrarFichaCiudadanoM($datosC, $tablaBD = 'ficha_sensibilizacion_ciudadana')
    {
        $cbd = ConexionBD::cBD();

        $query1 = "SELECT username FROM usuario WHERE username='$_SESSION[username]'";
        $result1 = $cbd->query($query1);
        $row1 = $result1->fetch_array(MYSQLI_NUM);
        $username = $row1[0];

        $nombres = mysql_entities_fix_string($cbd, $datosC['nombres']);
        $sexo = mysql_entities_fix_string($cbd, $datosC['sexo']);
        $dni = mysql_entities_fix_string($cbd, $datosC['dni']);
        $telefono = mysql_entities_fix_string($cbd, $datosC['telefono']);
        $fecha = mysql_entities_fix_string($cbd, $datosC['fecha']);
        $id_campania = mysql_entities_fix_string($cbd, $datosC['id_campania']); // <-- Captura el ID

        $query = "INSERT INTO $tablaBD (username, id_campania, nombres, sexo, dni, telefono, fecha) 
                  VALUES ('$username', '$id_campania', '$nombres', '$sexo', '$dni', '$telefono', '$fecha')";

        return $cbd->query($query);
    }

    public function registrarFichaInstitucionM($datosC, $tablaBD = 'ficha_sensibilizacion_institucion')
    {
        $cbd = ConexionBD::cBD();

        $query1 = "SELECT username FROM usuario WHERE username='$_SESSION[username]'";
        $result1 = $cbd->query($query1);
        $row1 = $result1->fetch_array(MYSQLI_NUM);
        $username = $row1[0];

        $nombres = mysql_entities_fix_string($cbd, $datosC['nombres']);
        $sexo = mysql_entities_fix_string($cbd, $datosC['sexo']);
        $dni = mysql_entities_fix_string($cbd, $datosC['dni']);
        $telefono = mysql_entities_fix_string($cbd, $datosC['telefono']);
        $nombre_institucion = mysql_entities_fix_string($cbd, $datosC['nombre_institucion']);
        $fecha = mysql_entities_fix_string($cbd, $datosC['fecha']);
        $id_campania = mysql_entities_fix_string($cbd, $datosC['id_campania']); // <-- Captura el ID

        $query = "INSERT INTO $tablaBD (username, id_campania, nombres, sexo, dni, telefono, nombre_institucion, fecha) 
                  VALUES ('$username', '$id_campania', '$nombres', '$sexo', '$dni', '$telefono', '$nombre_institucion', '$fecha')";

        return $cbd->query($query);
    }
    // Nueva función para recuperar una sola campaña por su ID
    public function mostrarCampaniaIndividualM($id_campania, $tablaBD = 'campanias')
    {
        $cbd = ConexionBD::cBD();
        // Añadimos 'lugar' a la consulta SQL
        $query = "SELECT id_campania, nombre_campania, lugar, tipo_reunion FROM $tablaBD WHERE id_campania = '$id_campania'";
        $result = $cbd->query($query);
        return $result->fetch_array(MYSQLI_ASSOC);
    }

    public function registrarEmpleadosM($datosC, $tablaBD = 'datos')
    {

        $cbd = ConexionBD::cBD();

        $query1 = "SELECT username FROM usuario
        WHERE username='$_SESSION[username]'";
        $result1 = $cbd->query($query1);
        $row1 = $result1->fetch_array(MYSQLI_NUM);
        $username = $row1[0];
        $nombre = mysql_entities_fix_string($cbd, $datosC['titulo']);
        $apellido = mysql_entities_fix_string($cbd, $datosC['contenido']);
        $email = mysql_entities_fix_string($cbd, $datosC['fecha']);
        $foto = mysqli_escape_string($cbd, $datosC['foto']);
        $query = "INSERT INTO $tablaBD VALUES 
            (Null,'$username','$nombre', '$apellido', '$email','$foto',1)";

        $result = $cbd->query($query);

        return $result;
    }

    public function mostrarEmpleadosM($tablaBD = 'datos')
    {
        $cbd = ConexionBD::cBD();
        $query1 = "SELECT username FROM usuario
        WHERE username='$_SESSION[username]'";
        $result1 = $cbd->query($query1);
        $row1 = $result1->fetch_array(MYSQLI_NUM);
        $username = $row1[0];
        $query = "SELECT IDDatos,titulo, Contenido, fecha,foto,Estado FROM $tablaBD where username='$username' and (Estado=2 or Estado=1)";
        $result = $cbd->query($query);
        return $result;
    }
    public function mostrarEmpleadosArchivadosM($tablaBD = 'datos')
    {
        $cbd = ConexionBD::cBD();
        $query1 = "SELECT username FROM usuario
        WHERE username='$_SESSION[username]'";
        $result1 = $cbd->query($query1);
        $row1 = $result1->fetch_array(MYSQLI_NUM);
        $username = $row1[0];
        $query = "SELECT IDDatos,titulo, Contenido, fecha,foto,Estado FROM $tablaBD where username='$username' and Estado=0 ";
        $result = $cbd->query($query);
        return $result;
    }
    public function mostrarEmpleadosFavoritosM($tablaBD = 'datos')
    {
        $cbd = ConexionBD::cBD();
        $query1 = "SELECT username FROM usuario
        WHERE username='$_SESSION[username]'";
        $result1 = $cbd->query($query1);
        $row1 = $result1->fetch_array(MYSQLI_NUM);
        $username = $row1[0];
        $query = "SELECT IDDatos,titulo, Contenido, fecha,foto,Estado FROM $tablaBD where username='$username' and Estado=2 ";
        $result = $cbd->query($query);
        return $result;
    }
    public function mostrarFiltroEmpleadosM($datosC, $tablaBD = 'datos')
    {
        $cbd = ConexionBD::cBD();
        $FechaI = $datosC['FechaI'];
        $FechaF = $datosC['FechaF'];
        $query1 = "SELECT username FROM usuario
        WHERE username='$_SESSION[username]'";
        $result1 = $cbd->query($query1);
        $row1 = $result1->fetch_array(MYSQLI_NUM);
        $username = $row1[0];
        $query = "datos.fecha>='$FechaI' and datos.fecha<='$FechaF' order by fecha asc";
        $query = "SELECT IDDatos,titulo, Contenido, fecha,foto,Estado FROM $tablaBD where username='$username' and fecha between '$FechaI' and DATE_ADD('$FechaF',interval 1 DAY)";
        $result = $cbd->query($query);
        return $result;
    }
    public function mostrarFiltroPalabraM($datosC, $tablaBD = 'datos')
    {
        $cbd = ConexionBD::cBD();
        $Palabra = $datosC['Palabra'];
        $query1 = "SELECT username FROM usuario
        WHERE username='$_SESSION[username]'";
        $result1 = $cbd->query($query1);
        $row1 = $result1->fetch_array(MYSQLI_NUM);
        $username = $row1[0];
        $query = "SELECT IDDatos,titulo, Contenido, fecha,foto,Estado FROM $tablaBD where username='$username' and (titulo like '%$Palabra%' or Contenido like '%$Palabra%')";;
        $result = $cbd->query($query);
        return $result;
    }
    public function editarEmpleadoM($datosC, $tablaBD = 'datos')
    {
        $cbd = ConexionBD::cBD();
        $IDDatos = $datosC['IDDatos'];
        $query = "SELECT IDDatos,titulo, Contenido, fecha,foto,Estado FROM $tablaBD WHERE IDDatos='$IDDatos'";
        $result = $cbd->query($query);
        $rows = $result->fetch_array(MYSQLI_ASSOC);
        return $rows;
    }

    public function actualizarEmpleadoM($datosC, $tablaBD = 'datos')
    {
        $cbd = ConexionBD::cBD();
        $query1 = "SELECT username FROM usuario
        WHERE username='$_SESSION[username]'";
        $result1 = $cbd->query($query1);
        $row1 = $result1->fetch_array(MYSQLI_NUM);
        $username = $row1[0];
        extract($datosC);
        $titulo = mysql_entities_fix_string($cbd, $datosC['titulo']);
        $Contenido = mysql_entities_fix_string($cbd, $datosC['Contenido']);
        $fecha = mysql_entities_fix_string($cbd, $datosC['fecha']);
        $foto = mysqli_escape_string($cbd, $datosC['foto']);
        if ($foto == NULL) {
            $query = "UPDATE $tablaBD
            SET IDDatos='$IDDatos',
            username='$username',
            titulo='$titulo', 
            Contenido='$Contenido', 
            fecha='$fecha'
            WHERE IDDatos=$IDDatos";
        } else {
            $query = "UPDATE $tablaBD
            SET IDDatos='$IDDatos',
            username='$username',
            titulo='$titulo', 
            Contenido='$Contenido', 
            fecha='$fecha',
            foto='$foto'
            WHERE IDDatos=$IDDatos";
        }

        echo $query;
        $resultado = $cbd->query($query);
        return $resultado;
    }

    public function borrarEmpleadoM($datosC, $tablaBD = 'datos')
    {
        $cbd = ConexionBD::cBD();
        extract($datosC);
        $query = "DELETE FROM $tablaBD WHERE IDDatos='$IDDatos'";
        $resultado = $cbd->query($query);
    }

    public function favoritoEmpleadoM($datosC, $tablaBD = 'datos')
    {
        $cbd = ConexionBD::cBD();
        $id = $datosC['IDDatos'];
        $query = "UPDATE $tablaBD
        SET Estado = '2' WHERE IDDatos=$id";
        $result = $cbd->query($query);
    }
    public function QfavoritoEmpleadoM($datosC, $tablaBD = 'datos')
    {
        $cbd = ConexionBD::cBD();
        $id = $datosC['IDDatos'];
        $query = "UPDATE $tablaBD
        SET Estado = '1' WHERE IDDatos=$id";
        $result = $cbd->query($query);
    }
    public function ArchivarEmpleadoM($datosC, $tablaBD = 'datos')
    {
        $cbd = ConexionBD::cBD();
        $id = $datosC['IDDatos'];
        $query = "UPDATE $tablaBD
        SET Estado = '0' WHERE IDDatos=$id";
        $result = $cbd->query($query);
    }
}
