<?php
//Conexion
$conexion=new mysqli('localhost','root','','alcosmamani');
//Base de datos


?>