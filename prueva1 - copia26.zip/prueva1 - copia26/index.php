<?php //index.php

// 1. Iniciar sesión globalmente
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 2. Requerir todos los archivos MVC
require_once 'Controladores/rutasC.php';
require_once 'Controladores/adminC.php';
require_once 'Controladores/empleadosC.php';
require_once 'Controladores/crearusuarioC.php';

require_once 'Modelos/rutasM.php';
require_once 'Modelos/adminM.php';
require_once 'Modelos/empleadosM.php';
require_once 'Modelos/crearusuarioM.php';
require_once 'Modelos/conexionBD.php';


// =======================================================================
// 3A. INTERCEPTOR PARA EXPORTAR WORD (Asistentes de Campañas)
// =======================================================================
if (isset($_GET['action']) && $_GET['action'] == 'exportarWord' && isset($_GET['id_campania'])) {

    if (!isset($_SESSION['rol']) || $_SESSION['rol'] != 'administrador') {
        header('location: index.php?ruta=empleados');
        exit();
    }

    $cbd = ConexionBD::cBD();
    $id_campania = $cbd->real_escape_string($_GET['id_campania']);

    $queryCampania = "SELECT nombre_campania, lugar, fecha, tipo_reunion FROM campanias WHERE id_campania = '$id_campania'";
    $resCampania = $cbd->query($queryCampania);
    $infoCampania = $resCampania->fetch_array(MYSQLI_ASSOC);

    $queryAsistentes = "SELECT nombres, sexo, dni, telefono 
                        FROM ficha_sensibilizacion_ciudadana 
                        WHERE id_campania = '$id_campania'
                        UNION ALL
                        SELECT nombres, sexo, dni, telefono 
                        FROM ficha_sensibilizacion_institucion 
                        WHERE id_campania = '$id_campania'";
    $listaAsistentes = $cbd->query($queryAsistentes);

    $nombreFile = "Lista_Asistentes_" . $id_campania . ".doc";
    if (ob_get_length()) ob_clean();

    header("Content-type: application/vnd.ms-word; charset=utf-8");
    header("Content-Disposition: attachment; filename=\"$nombreFile\"");
    header("Pragma: no-cache");
    header("Expires: 0");

?>
    <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>

    <head>
        <meta charset="utf-8">
        <style>
            @page Section1 {
                size: 11.0in 8.5in;
                mso-page-orientation: landscape;
                margin: 1.0in 1.0in 1.0in 1.0in;
            }

            div.Section1 {
                page: Section1;
            }

            body {
                font-family: "Times New Roman", serif;
                font-size: 11pt;
                color: black;
            }

            .encabezado-titulo {
                text-align: center;
                font-size: 14pt;
                font-weight: bold;
                margin-bottom: 10px;
                text-decoration: underline;
            }

            .encabezado-texto {
                text-align: left;
                font-size: 11pt;
                line-height: 1.5;
                margin-bottom: 20px;
            }

            .tabla-datos {
                width: 100%;
                border-collapse: collapse;
                margin-top: 15px;
            }

            .tabla-datos th,
            .tabla-datos td {
                border: 1px solid black;
                padding: 6px;
                font-size: 11pt;
            }

            .tabla-datos th {
                font-weight: bold;
                text-align: center;
            }

            .nota-pie {
                margin-top: 15px;
                font-size: 10pt;
            }

            .firma-seccion {
                margin-top: 50px;
                text-align: center;
                width: 100%;
            }

            .linea-firma {
                border-top: 1px solid black;
                width: 250px;
                margin: 0 auto;
                padding-top: 5px;
            }
        </style>
    </head>

    <body>
        <div class="Section1">
            <p class="encabezado-titulo">Municipalidad Distrital de Santa María de Chicmo</p>
            <p class="encabezado-texto" style="border-bottom: 1px solid black; padding-bottom: 10px;">
                <strong>ACTIVIDAD:</strong> <?php echo mb_strtoupper($infoCampania['nombre_campania'], 'UTF-8'); ?><br>
                <strong>FECHA:</strong> <?php echo date('d/m/Y', strtotime($infoCampania['fecha'])); ?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <strong>LUGAR:</strong> <?php echo mb_strtoupper($infoCampania['lugar'], 'UTF-8'); ?>
            </p>
            <table class="tabla-datos">
                <thead>
                    <tr>
                        <th style="width: 5%;">N°</th>
                        <th style="width: 45%;">NOMBRES Y APELLIDOS</th>
                        <th style="width: 10%;">Sexo</th>
                        <th style="width: 20%;">DNI</th>
                        <th style="width: 20%;">Número de teléfono</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $contador = 1;
                    if ($listaAsistentes) {
                        while ($row = $listaAsistentes->fetch_array(MYSQLI_ASSOC)):
                            $sexoFormateado = '';
                            if (strtolower($row['sexo']) == 'masculino') $sexoFormateado = 'M';
                            else if (strtolower($row['sexo']) == 'femenino') $sexoFormateado = 'F';
                            else $sexoFormateado = $row['sexo'];
                    ?>
                            <tr>
                                <td style="text-align:center;"><?php echo $contador++; ?></td>
                                <td><?php echo mb_strtoupper($row['nombres'], 'UTF-8'); ?></td>
                                <td style="text-align:center;"><?php echo $sexoFormateado; ?></td>
                                <td style="text-align:center;"><?php echo $row['dni']; ?></td>
                                <td style="text-align:center;"><?php echo $row['telefono']; ?></td>
                            </tr>
                    <?php endwhile;
                    } ?>
                </tbody>
            </table>
            <p class="nota-pie">*Femenino(F)/Masculino(M)</p>
            <div class="firma-seccion">
                <div class="linea-firma"><strong>Firma y sello</strong><br>Municipalidad Provincial de ………………………………………</div>
            </div>
        </div>
    </body>

    </html>
<?php
    exit();
}


// =======================================================================
// 3B. INTERCEPTOR PARA EXPORTAR EXCEL (Filtrado por Fecha del Calendario)
// =======================================================================
if (isset($_GET['action']) && $_GET['action'] == 'exportarExcelFecha' && isset($_GET['fecha_filtro'])) {

    // Seguridad para descargar el Excel
    if (!isset($_SESSION['rol']) || $_SESSION['rol'] != 'administrador') {
        header('location: index.php?ruta=reciclaje');
        exit();
    }

    $cbd = ConexionBD::cBD();

    // Escapar la fecha recibida del formulario para evitar inyección SQL
    $fecha_solicitada = $cbd->real_escape_string($_GET['fecha_filtro']);

    // Consulta filtrada estricta por el día seleccionado
    $queryHistorial = "SELECT r.id_registro, s.nombre_sector, r.cantidad_kg, r.placa_vehiculo, r.fecha, r.registrado_por 
                       FROM registro_reciclaje r 
                       INNER JOIN sectores s ON r.id_sector = s.id_sector 
                       WHERE r.fecha = '$fecha_solicitada' 
                       ORDER BY r.id_registro DESC";
    $historial = $cbd->query($queryHistorial);

    $nombreFile = "Reporte_Diario_" . $fecha_solicitada . ".xls";

    if (ob_get_length()) ob_clean();

    // Cabeceras HTTP para forzar Excel
    header("Content-Type: application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=\"$nombreFile\"");
    header("Pragma: no-cache");
    header("Expires: 0");

    echo "<meta charset=\"utf-8\">";
    echo "<table border='0'>";

    // Título Principal
    echo "<tr><td colspan='6' style='font-size: 16px; font-weight: bold; text-align: left;'>MUNICIPALIDAD DISTRITAL DE SANTA MARÍA DE CHICMO</td></tr>";

    // Subtítulo Dinámico que muestra la fecha exacta elegida en el calendario
    $fecha_legible = date('d/m/Y', strtotime($fecha_solicitada));
    echo "<tr><td colspan='6' style='font-size: 13px; text-align: left; font-style: italic; color: #444;'>Reporte Diario de Ingreso de Residuos - Correspondiente al día: $fecha_legible</td></tr>";
    echo "<tr><td colspan='6'></td></tr>";

    // Cabecera Verde
    echo "<tr>
            <th style='background-color: #1B5E20; color: #FFFFFF; font-weight: bold; border: 1px solid #CCCCCC; padding: 5px;'>N°</th>
            <th style='background-color: #1B5E20; color: #FFFFFF; font-weight: bold; border: 1px solid #CCCCCC; padding: 5px;'>FECHA</th>
            <th style='background-color: #1B5E20; color: #FFFFFF; font-weight: bold; border: 1px solid #CCCCCC; padding: 5px;'>SECTOR / ZONA</th>
            <th style='background-color: #1B5E20; color: #FFFFFF; font-weight: bold; border: 1px solid #CCCCCC; padding: 5px;'>PLACA DEL VEHÍCULO</th>
            <th style='background-color: #1B5E20; color: #FFFFFF; font-weight: bold; border: 1px solid #CCCCCC; padding: 5px;'>VOLUMEN (M³)</th>
            <th style='background-color: #1B5E20; color: #FFFFFF; font-weight: bold; border: 1px solid #CCCCCC; padding: 5px;'>REGISTRADO POR</th>
          </tr>";

    $suma_total = 0;
    $contador = 1;

    // Solo recorre si hay resultados para ese día
    if ($historial && mysqli_num_rows($historial) > 0) {
        while ($row = $historial->fetch_array(MYSQLI_ASSOC)) {
            $suma_total += $row['cantidad_kg'];
            $color_fila = ($contador % 2 == 0) ? '#F4F9F4' : '#FFFFFF';

            echo "<tr style='background-color: $color_fila;'>
                    <td style='border: 1px solid #CCCCCC; text-align: center;'>" . $contador++ . "</td>
                    <td style='border: 1px solid #CCCCCC; text-align: center;'>" . date('d/m/Y', strtotime($row['fecha'])) . "</td>
                    <td style='border: 1px solid #CCCCCC;'>" . mb_strtoupper($row['nombre_sector'], 'UTF-8') . "</td>
                    <td style='border: 1px solid #CCCCCC; text-align: center; font-weight: bold;'>" . $row['placa_vehiculo'] . "</td>
                    <td style='border: 1px solid #CCCCCC; text-align: right;'>" . number_format($row['cantidad_kg'], 2) . "</td>
                    <td style='border: 1px solid #CCCCCC;'>" . $row['registrado_por'] . "</td>
                  </tr>";
        }
    } else {
        // Mensaje estético en el Excel si el administrador descarga un día que no tiene registros
        echo "<tr><td colspan='6' style='text-align: center; color: red; padding: 15px; border: 1px solid #CCCCCC;'>No hay ingresos registrados en esta fecha.</td></tr>";
    }

    // Fila final de sumatoria del día
    echo "<tr>
            <td colspan='3' style='border-top: 1px solid #1B5E20; border-bottom: 2px solid #1B5E20; background-color: #E8F5E9; text-align: right; font-weight: bold; color: #1B5E20; padding: 5px;'>TOTAL DEL DÍA:</td>
            <td style='border-top: 1px solid #1B5E20; border-bottom: 2px solid #1B5E20; background-color: #E8F5E9;'></td>
            <td style='border-top: 1px solid #1B5E20; border-bottom: 2px solid #1B5E20; background-color: #E8F5E9; text-align: right; font-weight: bold; color: #1B5E20; padding: 5px;'>" . number_format($suma_total, 2) . " M³</td>
            <td style='border-top: 1px solid #1B5E20; border-bottom: 2px solid #1B5E20; background-color: #E8F5E9;'></td>
          </tr>";

    echo "</table>";
    exit();
}


// =======================================================================
// 4. CARGAR EL SISTEMA WEB NORMALMENTE SI NO HAY DESCARGAS
// =======================================================================
ob_start();

$rutas = new RutasC();
$plantilla = $rutas->plantillaC();
require_once $plantilla;

ob_end_flush();
?>

