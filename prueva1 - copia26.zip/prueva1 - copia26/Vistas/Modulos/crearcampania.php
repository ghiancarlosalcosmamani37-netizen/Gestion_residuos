<!DOCTYPE html>
<html lang="es">
<?php
// Verificamos que solo el administrador pueda ver esta vista
if ($_SESSION['rol'] != 'administrador') {
    header('location: index.php?ruta=empleados');
    exit();
}

$registrar = new EmpleadosC();
$registrar->registrarCampaniaC();
?>

<div class="loginTitle">
    <h4>CREAR NUEVA CAMPAÑA O REUNIÓN</h4>
</div>

<body class="bodyLogin">

    <head>
        <link rel="stylesheet" type="text/css" href="Vistas/css/estilos.css">
    </head>
    <div class="container">
        <div class="loginsinDiv">
            <div class="row loginContainer">
                <form method="post" action="">
                    <div class="col s12 m12 l12">

                        <div class="input-field">
                            <label class="active">Nombre de la Campaña</label>
                            <input type="text" placeholder="Ej: Campaña de limpieza por el Día Mundial de acción..." name="nombre_campania" required>
                        </div>

                        <div class="input-field">
                            <input type="date" id="fecha_evento" name="fecha" placeholder=" " required>

                            <label for="fecha_evento" class="active">Fecha del Evento</label>
                        </div>

                        <div class="input-field">
                            <label class="active">Lugar</label>
                            <input type="text" placeholder="Ej: Rio Chicmo" name="lugar" required>
                        </div>

                        <div class="input-field">
                            <label class="active">Tipo de Reunión</label>
                            <select name="tipo_reunion" style="display: block;" required>
                                <option value="" disabled selected>Seleccione el tipo de sensibilización</option>
                                <option value="Sensibilización ciudadana">Sensibilización ciudadana</option>
                                <option value="Sensibilización a institución">Sensibilización a institución</option>
                            </select>
                        </div>

                        <div style="margin-top: 30px;">
                            <button class="btn col l12 s12 m12 red darken-4" type="submit" name="guardar_campania">Crear Campaña</button>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>
</body>