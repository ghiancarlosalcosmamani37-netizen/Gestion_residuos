<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - Sistema Web 3R</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

  <style>
    body,
    html {
      margin: 0;
      padding: 0;
      height: 100%;
      font-family: 'Arial', sans-serif;
    }

    /* Contenedor del fondo */
    .login-background {
      height: 100vh;
      background-image: url('Imagenes/inicio.jpg');
      /* Reemplaza con tu imagen o variable */
      background-size: cover;
      background-position: center;
      display: flex;
      justify-content: center;
      align-items: center;
      position: relative;
    }

    /* Efecto Vidrio esmerilado */
    .login-glass-container {
      background: rgba(255, 255, 255, 0.75);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.5);
      border-radius: 15px;
      padding: 40px 30px;
      width: 100%;
      max-width: 360px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
      text-align: center;
    }

    .login-logo {
      width: 120px;
      margin: 0 auto 15px auto;
    }

    .login-title {
      color: #212121;
      font-weight: 900;
      font-size: 22px;
      margin-top: 0;
      margin-bottom: 30px;
      line-height: 1.2;
    }

    .input-group {
      position: relative;
      margin-bottom: 20px;
    }

    .input-group i {
      position: absolute;
      left: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: #757575;
      font-size: 20px;
    }

    .input-group input {
      width: 100%;
      padding: 14px 15px 14px 45px;
      border: 1px solid #cfd8dc;
      border-radius: 8px;
      font-size: 15px;
      box-sizing: border-box;
      background: rgba(255, 255, 255, 0.95);
      outline: none;
      transition: all 0.3s ease;
    }

    .input-group input:focus {
      border-color: #1B5E20;
      box-shadow: 0 0 0 2px rgba(27, 94, 32, 0.2);
    }

    .btn-iniciar {
      width: 100%;
      background-color: #1B5E20;
      color: white;
      border: none;
      padding: 14px;
      border-radius: 8px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.3s ease;
      margin-bottom: 20px;
      box-shadow: 0 4px 6px rgba(27, 94, 32, 0.3);
    }

    .btn-iniciar:hover {
      background-color: #124016;
    }

    .login-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .login-footer a {
      color: #424242;
      text-decoration: none;
      font-size: 13px;
      display: flex;
      align-items: center;
      gap: 5px;
      transition: color 0.3s;
    }

    .login-footer a:hover {
      color: #1B5E20;
    }

    /* Contenedor principal */
    .input-group {
      position: relative;
      display: flex;
      align-items: center;
      margin-bottom: 15px;
      /* Espacio de separación por si tienes más campos */
      width: 100%;
      max-width: 300px;
      /* Ajusta el ancho a tu gusto */
    }

    /* Estilo para el icono */
    .input-group .material-icons {
      position: absolute;
      left: 10px;
      /* Lo separa un poco del borde izquierdo */
      color: #777;
      /* Un color gris suave para el icono */
      pointer-events: none;
      /* Hace que si dan clic al icono, se active el input */
    }

    /* Estilo para el campo de contraseña */
    .input-group input[type="password"] {
      width: 100%;
      padding: 10px 10px 10px 40px;
      /* ¡La clave está aquí! 40px a la izquierda para dejarle espacio al icono */
      border: 1px solid #ccc;
      border-radius: 4px;
      font-size: 16px;
      outline: none;
    }

    /* Efecto visual cuando el usuario hace clic en el input */
    .input-group input[type="password"]:focus {
      border-color: #007bff;
      /* Cambia a azul al seleccionarlo */
    }

    /* Contenedor principal de cada campo */
    .input-group {
      position: relative;
      display: flex;
      align-items: center;
      margin-bottom: 20px;
      /* Un poco más de espacio entre campos */
      width: 100%;
      max-width: 320px;
      /* Ancho ideal para formularios móviles y web */
    }

    /* Estilo para TODOS los iconos dentro de un input-group */
    .input-group .material-icons {
      position: absolute;
      left: 12px;
      /* Separación desde el borde izquierdo */
      color: #888888;
      /* Color gris neutral para los iconos */
      pointer-events: none;
      transition: color 0.3s ease;
      /* Suaviza el cambio de color */
    }

    /* Estilo para TODOS los inputs (Texto y Password) */
    .input-group input[type="text"],
    .input-group input[type="password"] {
      width: 100%;
      padding: 12px 12px 12px 42px;
      /* 42px a la izquierda para proteger el espacio del icono */
      border: 1px solid #dadce0;
      /* Borde suave estilo Google */
      border-radius: 6px;
      /* Esquinas ligeramente redondeadas */
      font-size: 15px;
      outline: none;
      background-color: #fff;
      transition: all 0.3s ease;
      /* Transición suave para el enfoque */
    }

    /* Efecto cuando el usuario hace clic en el input */
    .input-group input:focus {
      border-color: #1a73e8;
      /* Azul moderno al seleccionar */
      box-shadow: 0 1px 3px rgba(26, 115, 232, 0.2);
      /* Pequeña sombra azul */
    }

    /* Extra: Cambia el color del icono cuando el input está activo */
    .input-group input:focus~.material-icons {
      color: #1a73e8;
    }
  </style>
</head>

<body>

  <div class="login-background">
    <div class="login-glass-container">

      <img src="Imagenes/timon_logo.png" alt="Logo Timón" class="login-logo">

      <h3 class="login-title">BIENVENIDO AL<br>SISTEMA</h3>

      <form method="post" action="">

        <div class="input-group">
          <i class="material-icons">account_circle</i>
          <input type="text" name="usuarioI" placeholder="Usuario" required>
        </div>

        <div class="input-group">
          <i class="material-icons input-icon">vpn_key</i>
          <input type="password" name="claveI" placeholder="Contraseña" required>
        </div>

        <button type="submit" class="btn-iniciar">INGRESAR</button>

      </form>

      <?php
      // Se mantiene el llamado a tu controlador original fuera del form, justo como lo tenías
      $ingreso = new AdminC();
      $ingreso->IngresoC();
      ?>

      <div class="login-footer" style="justify-content: center; margin-top: 15px;">
        <a href="index.php?ruta=recuperar">¿Olvidaste tu contraseña?</a>
      </div>
    </div>
  </div>
  
</body>