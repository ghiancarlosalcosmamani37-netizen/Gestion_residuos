<div>
	<?php if ($rutasC->sesionIniciadaC()): ?>
	<?php else: ?>
		<div class="navbar-fixed">
			<nav class="#009688 teal">
				<div class="nav-wrapper" style="padding: 0 20px;">
					<a href="#" class="brand-logo left" style="font-size: 1.3rem;">
						Gestión Residuos (<?php echo ($_SESSION['rol'] == 'administrador') ? 'RESPONSABLE' : 'ASISTENTE'; ?>)
					</a>

					<ul class="right">
						<?php if ($_SESSION['rol'] == 'administrador'): ?>
							<li><a href="index.php?ruta=crearcampania">Crear Campaña</a></li>
							<li><a href="index.php?ruta=campanias">Ver Campañas</a></li>
							<li><a href="index.php?ruta=crearusuario">Añadir Asistente</a></li>
							<li><a href="index.php?ruta=reciclaje">Configurar Sectores</a></li>

						<?php else: ?>
							<li><a href="index.php?ruta=registrar">Registrar Ficha</a></li>
							<li><a href="index.php?ruta=reciclaje">Ingreso de Reciclaje</a></li>
							<li><a href="index.php?ruta=campanias">Ver Campañas</a></li>
						<?php endif; ?>

						<li><a href="index.php?ruta=usuario">Mi Cuenta</a></li>
						<li><a href="index.php?ruta=salir">Salir</a></li>

					</ul>
				</div>
			</nav>
		</div>
	<?php endif; ?>
</div>