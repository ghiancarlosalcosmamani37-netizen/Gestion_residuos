<?php
$reciclajeObj = new EmpleadosC();
$reciclajeObj->registrarSectorC();
$reciclajeObj->registrarReciclajeDiarioC();

$listaSectores = $reciclajeObj->mostrarSectoresC();
$historialReciclaje = $reciclajeObj->mostrarHistorialReciclajeC();
?>

<div class="loginTitle" style="margin-top: 20px;">
    <h4>GESTIÓN DE INGRESO DE RECICLAJE POR SECTOR</h4>
</div>

<div class="container">

    <?php if ($_SESSION['rol'] == 'administrador'): ?>
        <div class="card-panel white" style="border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); padding: 20px; margin-bottom: 30px;">
            <h5>Añadir Nuevo Sector o Zona de Recolección</h5>
            <form method="post" action="">
                <div class="row" style="margin-bottom: 0;">
                    <div class="input-field col s12 m8">
                        <input type="text" placeholder="Ej: Sector 4 - Urbanización Central" name="nombre_sector" required>
                    </div>
                    <div class="input-field col s12 m4">
                        <button type="submit" name="guardar_sector" class="btn col s12 red darken-4">
                            <i class="material-icons left">add_location</i> Registrar Sector
                        </button>
                    </div>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col s12">
            <h5>Sectores Disponibles para Ingreso Diario</h5>
            <?php if (mysqli_num_rows($listaSectores) > 0): ?>
                <table class="striped responsive-table white" style="border-radius: 8px; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <thead class="teal white-text">
                        <tr>
                            <th style="width: 10%;">ID</th>
                            <th style="width: 40%;">Nombre del Sector / Zona</th>
                            <th style="width: 50%;">Registrar Datos del Vehículo de Ingreso</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($sec = mysqli_fetch_array($listaSectores)): ?>
                            <tr>
                                <td><b><?php echo $sec['id_sector']; ?></b></td>
                                <td><?php echo mb_strtoupper($sec['nombre_sector'], 'UTF-8'); ?></td>
                                <td>
                                    <form method="post" action="" style="display: flex; flex-wrap: wrap; align-items: center; margin: 0;">
                                        <input type="hidden" name="id_sector" value="<?php echo $sec['id_sector']; ?>">

                                        <input type="text" placeholder="Placa Vehículo" name="placa_vehiculo" required
                                            style="width: 130px; margin-right: 15px; height: 2rem; font-size: 0.9rem;"
                                            oninput="this.value = this.value.toUpperCase();">

                                        <input type="number" step="0.01" min="0.01" placeholder="Volumen (M³)" name="cantidad_kg" required
                                            style="width: 120px; margin-right: 15px; height: 2rem; font-size: 0.9rem;">

                                        <button type="submit" name="guardar_reciclaje" class="btn-small red darken-4" title="Guardar Registro">
                                            <i class="material-icons">save</i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="card-panel yellow lighten-4 center text-darken-4">
                    <p>No hay sectores registrados en el sistema. El administrador debe añadir sectores primero.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row" style="margin-top: 30px;">
        <div class="col s12">

            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; margin-bottom: 15px; background: #f5f5f5; padding: 10px 15px; border-radius: 8px;">
                <h5 style="margin: 0; font-size: 1.3rem;">Historial General de Ingresos</h5>

                <?php if ($_SESSION['rol'] == 'administrador'): ?>
                    <form action="index.php" method="GET" style="display: flex; align-items: center; margin: 0;">
                        <input type="hidden" name="action" value="exportarExcelFecha">

                        <label style="margin-right: 10px; font-weight: bold; color: #1B5E20;">Seleccione un día:</label>
                        <input type="date" name="fecha_filtro" required
                            value="<?php echo date('Y-m-d'); ?>"
                            style="height: 2.5rem; margin-right: 15px; width: auto; background: white; border: 1px solid #ccc; padding: 0 10px; border-radius: 4px;">

                        <button type="submit" class="btn green darken-3" style="display: flex; align-items: center;">
                            <i class="material-icons left">event_note</i> Descargar Excel del Día
                        </button>
                    </form>
                <?php endif; ?>
            </div>

            <?php if (mysqli_num_rows($historialReciclaje) > 0): ?>
                <table class="striped responsive-table white" style="border-radius: 8px; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <thead class="grey darken-3 white-text">
                        <tr>
                            <th>Fecha</th>
                            <th>Sector / Zona</th>
                            <th>Placa Vehículo</th>
                            <th>Cantidad Ingresada (M³)</th>
                            <th>Registrado Por</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($hist = mysqli_fetch_array($historialReciclaje)): ?>
                            <tr>
                                <td><?php echo date('d/m/Y', strtotime($hist['fecha'])); ?></td>
                                <td><strong><?php echo mb_strtoupper($hist['nombre_sector'], 'UTF-8'); ?></strong></td>
                                <td><span class="chip white-text grey darken-2"><?php echo $hist['placa_vehiculo']; ?></span></td>
                                <td style="color: #b71c1c; font-weight: bold;"><?php echo $hist['cantidad_kg']; ?> M³</td>
                                <td><i class="material-icons left" style="font-size: 1.1rem; margin-right: 5px;">person</i><?php echo $hist['registrado_por']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="card-panel blue-grey lighten-5 center">
                    <p>Aún no se han registrado ingresos de reciclaje en el sistema.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

</div>