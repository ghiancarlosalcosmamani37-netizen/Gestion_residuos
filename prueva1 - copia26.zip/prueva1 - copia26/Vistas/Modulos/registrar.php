<?php
$registrar = new EmpleadosC();
$registrar->registrarEmpleadosC();

$campaniaSeleccionada = false;
if(isset($_GET['id_campania'])) {
    $infoCampania = $registrar->mostrarCampaniaIndividualC($_GET['id_campania']);
    if($infoCampania) {
        $campaniaSeleccionada = true;
        $idCampania = $infoCampania['id_campania'];
        $nombreCampania = $infoCampania['nombre_campania'];
        $lugarCampania = $infoCampania['lugar']; // Extraemos el lugar definido por el administrador
        
        // Identificación de la campaña ignorando mayúsculas, minúsculas o tildes
        $tipo_reunion_db = strtolower(trim($infoCampania['tipo_reunion']));
        if (strpos($tipo_reunion_db, 'ciudadana') !== false) {
            $tipoDeterminado = 'Ciudadano';
        } else {
            $tipoDeterminado = 'Institución';
        }
    }
}

// Seguridad: Si no hay campaña seleccionada, regresa al listado de campañas
if(!$campaniaSeleccionada) {
    header('location: index.php?ruta=campanias');
    exit();
}
?>

<div class="loginTitle" style="margin-top: 20px;">
    <h4>REGISTRO DE ASISTENCIA</h4>
    <h5 style="color: #b71c1c; font-weight: bold; margin-bottom: 25px;">Campaña: <?php echo $nombreCampania; ?></h5>
</div>

<body class="bodyLogin">
	<head>
	    <link rel="stylesheet" type="text/css" href="Vistas/css/estilos.css">
	</head>	
<div class="container">
    <div class="loginsinDiv">
        <div class="row loginContainer">
		<form method="post" action="">
            <div class="col s12 m12 l12">
                
                <input type="hidden" name="id_campania" value="<?php echo $idCampania; ?>">

                <div class="row" style="margin-bottom: 25px;">
                    <div class="col s12 m6 input-field">
                        <label class="active" style="font-size: 1rem; color: #00796b; font-weight: bold;">Tipo de Registro Programado</label>
                        <input type="text" value="<?php echo $tipoDeterminado; ?>" disabled style="color: #212121; font-weight: 500; border-bottom: 2px solid #00796b;">
                        <input type="hidden" name="tipo_entidad" value="<?php echo $tipoDeterminado; ?>">
                    </div>

                    <div class="col s12 m6 input-field">
                        <label class="active" style="font-size: 1rem; color: #00796b; font-weight: bold;">Lugar Establecido</label>
                        <input type="text" value="<?php echo $lugarCampania; ?>" disabled style="color: #212121; font-weight: 500; border-bottom: 2px solid #00796b;">
                    </div>
                </div>

                <div class="input-field">
                    <input type="text" placeholder="Nombres y Apellidos del Asistente" name="nombres" 
                           pattern="^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$" 
                           title="Solo se permiten letras y espacios" 
                           oninput="this.value = this.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '');" 
                           required>
                </div>

                <div class="input-field">
                    <select name="sexo" style="display: block;" required>
                        <option value="" disabled selected>Seleccione el sexo</option>
                        <option value="Masculino">Masculino</option>
                        <option value="Femenino">Femenino</option>
                    </select>
                </div>

                <div class="row">
                    <div class="col s12 m6">
                        <input type="text" placeholder="DNI" name="dni" 
                               pattern="\d{8}" 
                               maxlength="8" 
                               title="Debe ingresar exactamente 8 números" 
                               oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 8);" 
                               required>
                    </div>
                    <div class="col s12 m6">
                        <input type="text" placeholder="Número de Celular" name="telefono" 
                               pattern="\d{9}" 
                               maxlength="9" 
                               title="Debe ingresar exactamente 9 números" 
                               oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 9);" 
                               required>
                    </div>
                </div>

                <?php if($tipoDeterminado === 'Institución'): ?>
                    <div class="input-field" style="margin-top: 25px;">
                        <input type="text" placeholder="Nombre de la Institución a la que representa" name="nombre_institucion" required>
                    </div>
                <?php endif; ?>

                <div style="margin-top: 35px;">
                    <button class="btn col l12 s12 m12 red darken-4" type="submit" name="guardar">Confirmar y Guardar Asistencia</button>
                </div>
            </div>  
        </form>
        </div>
    </div>	
</div>
</body>