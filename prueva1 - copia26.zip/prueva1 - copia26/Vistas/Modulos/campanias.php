<?php
$campanias = new EmpleadosC();

// Determinar qué tabla mostrar según la selección del Administrador
$verAntiguas = (isset($_GET['ver']) && $_GET['ver'] == 'antiguas' && $_SESSION['rol'] == 'administrador');

if ($verAntiguas) {
    $listaCampanias = $campanias->mostrarCampaniasAntiguasC();
    $tituloSeccion = "HISTORIAL DE CAMPAÑAS ANTIGUAS";
} else {
    $listaCampanias = $campanias->mostrarCampaniasActivasC();
    $tituloSeccion = "CAMPAÑAS Y REUNIONES VIGENTES";
}
?>

<div class="loginTitle" style="margin-top: 20px;">
    <h4><?php echo $tituloSeccion; ?></h4>
</div>

<div class="container">
    <?php if ($_SESSION['rol'] == 'administrador'): ?>
        <div class="row" style="margin-bottom: 20px;">
            <div class="col s12 text-center">
                <?php if (!$verAntiguas): ?>
                    <a href="index.php?ruta=campanias&ver=antiguas" class="btn red darken-4">
                        <i class="material-icons left">history</i> Ver Campañas Antiguas
                    </a>
                <?php else: ?>
                    <a href="index.php?ruta=campanias" class="btn teal">
                        <i class="material-icons left">event</i> Volver a Campañas Vigentes
                    </a>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col s12">
            <?php if (mysqli_num_rows($listaCampanias) > 0): ?>

                <table class="striped responsive-table white">
                    <thead class="grey darken-3 white-text">
                        <tr>
                            <th>Nombre de la Campaña</th>
                            <th>Fecha</th>
                            <th>Lugar</th>
                            <th>Tipo de Reunión</th>
                            <th>Organizado por</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_array($listaCampanias)): ?>
                            <tr>
                                <td><strong><?php echo $row['nombre_campania']; ?></strong></td>
                                <td><?php echo date('d/m/Y', strtotime($row['fecha'])); ?></td>
                                <td><?php echo $row['lugar']; ?></td>
                                <td><?php echo $row['tipo_reunion']; ?></td>
                                <td><?php echo $row['creado_por']; ?></td>
                                <td>
                                    <?php if ($_SESSION['rol'] == 'administrador'): ?>
                                        <a href="index.php?action=exportarWord&id_campania=<?php echo $row['id_campania']; ?>" class="btn blue-grey darken-3 btn-small">
                                            <i class="material-icons left">description</i> Exportar Word
                                        </a>
                                    <?php else: ?>
                                        <a href="index.php?ruta=registrar&id_campania=<?php echo $row['id_campania']; ?>" class="btn red darken-4 btn-small">
                                            <i class="material-icons left">person_add</i> Registrar Asistentes
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>



            <?php else: ?>
                <div class="card-panel yellow lighten-4 yellow-text text-darken-4 center">
                    <i class="material-icons median">info_outline</i>
                    <p>No se encontraron campañas registradas en esta sección en este momento.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>