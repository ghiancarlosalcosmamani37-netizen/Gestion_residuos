<?php
$empleados = new EmpleadosC();
$pagina = $empleados->mostrarEmpleadosArchivadosC();
$empleados->borrarEmpleadoC();
?>

<div class="loginTitle">
<h4>Notas Archivadas</h4>
</div>
<body class="bodyLogin"  >
	<head>
	<link rel="stylesheet" type="text/css" href="Vistas/css/estilos.css">
	</head>	
	<div class="container">
		<?php foreach($pagina as $key => $value): ?>
		<div class="loginsinDiv">
			<div class="row loginContainer ">
			<div class="col s12 m12 ">
				<div class="loginTitle">
					<h5><?=$value['titulo']?></h5>
				</div>
				<div >
					<div style="text-align:left" class="col s12 m5" >
						<h6><?=$value['fecha']?></h6>
					</div>
				</div>
				<div class="row">
					<div class="col s12">
					<pre><?=$value['Contenido']?></pre>
					</div>
				</div>
				<div class="row">
					<div class="col s12">
						<ul>
						<?php if ($value['foto']==NULL):?>
						<?php else: ?>
							<td id="box">
							<img text-align="center" src="data:image/png;base64,<?php echo base64_encode($value['foto']);?>" ></td>
						<?php     
						endif; ?>
						</ul>
					</div>
				</div>
				<div>
					<!-- boton eliminar  -->
					<a class="btn-small red waves-effect waves-light bolitaBoton " href='index.php?ruta=empleados&IDDatos=<?=$value['IDDatos']?>'>
						<i class="material-icons left">delete</i>Eliminar</a>
					</a>
					<!-- Boton editar -->
					<a class="btn-small cyan darken-2 waves-effect waves-light bolitaBoton" href='index.php?ruta=editar&IDDatos=<?=$value['IDDatos']?>'>
						<i class="material-icons left">edit</i>Editar</a>
					</a>
					<!-- Boton Favorito -->
					<a class="btn-small black waves-effect waves-light bolitaBoton"  href='index.php?ruta=empleados&IDDatos2=<?=$value['IDDatos']?>'>
						<i class="material-icons left">star</i>Favorito</a>
					</a>
					    <!-- Boton Desarchivar -->  
					<a class="btn-small green darken-1 waves-effect waves-light bolitaBoton"  href='index.php?ruta=empleados&IDDatos1=<?=$value['IDDatos']?>'>
						<i class="material-icons left">unarchive</i>Desarchivar</a>
					</a>	
				</div>
			</div>
		</div>
    </div>	
	<?php endforeach; ?>
	</div>	
</body>
