<?php
$empleados = new EmpleadosC();
$pagina = $empleados->mostrarEmpleadosC();
$empleados->favoritoEmpleadoC();
$empleados->QfavoritoEmpleadoC();
$empleados->ArchivarEmpleadoC();

$empleados->borrarEmpleadoC();
$usuario = new CrearusuarioC();
$pagina = $usuario->mostrarUsuarioC();

?>

<body id="t1">
	<?php foreach ($pagina as $key => $value): ?>
		<div class="container">

			<form method="post" action="">
				<div class="loginTitle">
					<h4>Bienvenido <?= $value['username'] ?> </h4>
				</div>
			<?php endforeach; ?>
		</div>
		</div>
		</div>
</body>
