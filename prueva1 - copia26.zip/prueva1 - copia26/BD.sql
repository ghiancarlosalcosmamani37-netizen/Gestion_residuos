-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-08-2023 a las 00:17:25
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `alcosmamani`
--
CREATE DATABASE IF NOT EXISTS `alcosmamani` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `alcosmamani`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos`
--

CREATE TABLE `datos` (
  `IDDatos` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `titulo` char(50) NOT NULL,
  `Contenido` text NOT NULL,
  `fecha` datetime NOT NULL,
  `foto` longblob NOT NULL,
  `Estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `datos`
--

CREATE TABLE `campanias` (
  `id_campania` INT(11) AUTO_INCREMENT PRIMARY KEY,
  `nombre_campania` VARCHAR(255) NOT NULL,
  `fecha` DATE NOT NULL,
  `lugar` VARCHAR(255) NOT NULL,
  `tipo_reunion` VARCHAR(50) NOT NULL,
  `creado_por` VARCHAR(50) NOT NULL
);

-- --------------------------------------------------------
-- Tabla exclusiva para Ciudadanos
CREATE TABLE `ficha_sensibilizacion_ciudadana` (
  `id_ficha_c` INT(11) AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL,
  `nombres` VARCHAR(150) NOT NULL,
  `sexo` VARCHAR(15) NOT NULL,
  `dni` VARCHAR(8) NOT NULL,
  `telefono` VARCHAR(15) NOT NULL,
  `fecha` DATETIME NOT NULL
);

-- Tabla exclusiva para Instituciones
CREATE TABLE `ficha_sensibilizacion_institucion` (
  `id_ficha_i` INT(11) AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL,
  `nombres` VARCHAR(150) NOT NULL, -- Nombre del representante
  `sexo` VARCHAR(15) NOT NULL,
  `dni` VARCHAR(8) NOT NULL,
  `telefono` VARCHAR(15) NOT NULL,
  `nombre_institucion` VARCHAR(150) NOT NULL,
  `fecha` DATETIME NOT NULL
);
--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `username` varchar(50) NOT NULL,
  `Correo` varchar(100) NOT NULL,
  `password` char(250) NOT NULL,
  `fotoU` longblob NOT NULL,
  `rol` VARCHAR(50)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`username`, `Correo`, `password`, `fotoU`, `rol`) VALUES 
('responsable_medio', 'responsable@correo.com', '$2y$10$iFIKAKB6t.80sXS3a5bLReI5qsFy8soqXKM8yh/NDYsmfQojVcOdG', '', 'administrador'),
('123', 'ghiancarlosalcosmamani37@gmail.com', '$2y$10$iFIKAKB6t.80sXS3a5bLReI5qsFy8soqXKM8yh/NDYsmfQojVcOdG', '', 'registrador');


--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `datos`
--
ALTER TABLE `datos`
  ADD PRIMARY KEY (`IDDatos`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `datos`
--
ALTER TABLE `datos`
  MODIFY `IDDatos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
