<?php  //Controladores/adminC.php
class AdminC{
    function __construct(){
        $this->adminM = new AdminM();
    }

    public function IngresoC(){
        if(isset($_SESSION['Ingreso'])){
            // Redirección por rol si ya tiene sesión activa
            if($_SESSION['rol'] == 'administrador'){
                header("location: index.php?ruta=empleados");
            } else {
                header("location: index.php?ruta=registrar");
            }
            exit();
        }

        if(isset($_POST["usuarioI"])){
            $datosC = array(    
                        "usuario"=>$_POST["usuarioI"], 
                        "clave"=>$_POST["claveI"]);
            $result = $this->adminM->IngresoM($datosC);
            
            if($result == true){
                if(session_status() == PHP_SESSION_NONE) { 
                    session_start(); 
                }
                $_SESSION['Ingreso'] = true;
                
                // Redirección inteligente al iniciar sesión
                if($_SESSION['rol'] == 'administrador'){
                    header("location: index.php?ruta=empleados"); // El Responsable va a ver todos los registros
                } else {
                    header("location: index.php?ruta=registrar"); // El Asistente va directo al formulario de registro de reciclaje
                }
                exit();
            }
            else
                echo "ERROR AL INGRESAR";
        }
    }

    public function salirC(){
        session_start();
        session_destroy();
        header("location:index.php?ruta=ingreso");
    }
}
?>