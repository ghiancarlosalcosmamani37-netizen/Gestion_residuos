<?php  // Controladores/empleadosC.php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
class CrearusuarioC {
    function __construct(){
        $this->crearusuarioM = new CrearusuarioM();
    }

    public function registrarUsuarioC(){
        if(isset($_POST['nombreR'])){
            $datosC =array();
            $datosC['nombre'] = $_POST['nombreR'];
            $datosC['correo'] = $_POST['apellidoR'];
            $datosC['clave'] = $_POST['emailR'];
            $datosC['claver'] = $_POST['email1R'];
            $datosC['rol'] = 'registrador';
            $result = $this->crearusuarioM->registrarUsuarioM($datosC);
         
            
        }
    }
    public function mostrarUsuarioC(){
        $result = $this->crearusuarioM->mostrarUsuarioM();
        return $result;
    }
        //borrar empleado
    public function borrarUsuarioC(){
        if(isset($_GET['username'])){
            $datosC = array('username' => $_GET['username']);
            $tablaBD = 'usuario';
            $this->crearusuarioM->borrarUsuarioM($datosC, $tablaBD);
            header('location: index.php?ruta=salir');
        }
    }
        //editar empleados
        public function editarUsuarioC(){
            if(isset($_GET['username'])){
                $datosC = array('username'=>$_GET['username']);
                $result = $this->crearusuarioM->editarUsuarioM($datosC);
                return $result;
            }
        }
    
        //actualizar empleados
        public function actualizarUsuarioC(){
            if (isset($_REQUEST['GUARDAR'])) {
                $datosC = array(    'username' =>$_POST['nombreR'],
                                    'Correo' =>$_POST['correoR'],
                                );
    
                $resultado = $this->crearusuarioM->actualizarUsuarioM($datosC);
                header('location: index.php?ruta=salir');
                return $resultado;
            }
        }

        //foto 
        public function cambiarFotoUC(){
            if (isset($_REQUEST['guardar'])) {
                if (file_exists($_FILES['foto']['tmp_name'])) {
                    switch ($_FILES['foto']['type'])
                    {
                        case 'image/jpeg':  $ext = 'jpg'; break;
                        case 'image/gif':   $ext = 'jpg'; break;
                        case 'image/png':   $ext = 'png'; break;
                        case 'image/tiff':  $ext = 'tif'; break;
                        default:            $ext = ''; break;
                    }
                    if ($ext){
                        $nombreArchivo = $_FILES['foto']['name'];
                        $tamanoArchivo = $_FILES['foto']['size'];
                        $imagenSubida = fopen($_FILES['foto']['tmp_name'], 'r');
                        $binariosImagen = fread($imagenSubida, $tamanoArchivo);
                    }else {
                        echo "<script>
                        M.toast({html: 'Ingrese una imagen valida'})
                        </script>";
                        return('location: index.php?ruta=registrar');
                    }
                    $datosC =array();
                    $datosC['foto'] = $binariosImagen;
                    $result = $this->crearusuarioM->cambiarFotoUM($datosC);
                    header('location: index.php?ruta=usuario');
                }else {
                    echo '<script>alert("Ingrese una imagen valida")</script>';
                }
        }    
        }
        public function EliminarFotoUC(){
            if(isset($_GET['usernameFE'])){
                $datosC = array('username' => $_GET['usernameFE']);
                $tablaBD = 'usuario';
                $this->crearusuarioM->EliminarFotoUM($datosC, $tablaBD);
                header('location: index.php?ruta=usuario');
            }
        }
        public function enviarCodC(){
            if(isset($_POST['CorreoR'])){
                //print_r($_POST['CorreoR']);
            $datosC=array();
            $datosC = array('CorreoR' => $_POST['CorreoR']);
            
            if(sizeof($this->crearusuarioM->enviarCodM($datosC))>0){
                $lista=($this->crearusuarioM->enviarCodM($datosC));
                $user=$lista[0];
                $datosC =array();
                $longitud=rand(20, 50);
                $token=bin2hex(random_bytes(($longitud - ($longitud % 2)) / 2));
                $_SESSION['Token']=$token;
                $_SESSION['CorreoR']=$_POST['CorreoR'];
                

               header('location:index.php?ruta=verificar');
            }
            else{
                print_r("<script>
                M.toast({html: 'Correo no registrado'})
                </script>");
                return 0;

            }    
            try{
                    
                require 'phpMailer/src/PHPMailer.php';
                require 'phpMailer/src/SMTP.php';
                require 'phpMailer/src/Exception.php';
                
                $mail = new PHPMailer();
                //$headers .= "To: $mail\r\n";
                $mail->isSMTP();
                $mail->Host='smtp.gmail.com';
                $mail->SMTPAuth=true;
                $mail->Username='ghianalcosmamani2@gmail.com';
                $mail->Password='ecwdsgsayhnoadvz';
                $mail->SMTPSecure= 'tls';
                $mail->Port=587;  // o 465
    
                $mail->setFrom('ghianalcosmamani2@gmail.com','diario_personal');
                $mail->addAddress($_POST['CorreoR'],'Restablecer contraseña');
    
                $mail->isHTML(true);
                $mail->Subject='Datos para acceso de cuenta.';
    
    
                $mail->Body= '
                                <html>
                                    <body align="center">
                                        <center>
                                            <div>
                                                <img height="200px" src="https://img.freepik.com/vector-premium/laptop-lapiz-libro-ilustracion-dibujos-animados-educativos-dibujados-mano_288411-928.jpg?w=740"/>
                                            </div>
    
                                            <div style="background-color: #3498DB; padding: 5px; width: 500px;border-radius: 10px;">
                                                <strong><p style="font-family: inherit; color: white">¿HA OLVIDADO SU CONTRASEÑA?</p></strong>
                                            </div>
    
                                            <div style="padding: 5px; width: 500px">
                                                <p style="font-family: inherit; color: black">Hola, <strong>'.$user.'</strong></p>
                                                <p>¡Hubo una solicitud para enviar su contraseña!</p>
                                                <strong><p style="font-family: sans-serif;font-size: 30px; color: purple">'.$token.'</p></strong>
                                            </div>
    
                                            <div style="background-color: #A569BD; padding: 5px; width: 500px;border-radius: 10px;">
                                                <strong><p style="font-family: inherit; color: white">¿Tiene preguntas?</p></strong>
                                                <p style="color: white">Estamos aquí para ayudar, aprenda más sobre nosotros aquí o contacta con nosotros</p>
                                            </div>
                                            <p>@2022 Copyright | Personal Diary</p>
                                        </center>
                                    </body>
                                </html>';
                $mail->send();
                echo "enviado correctamente";
    
            } catch (Exception $e) {
                echo "error en el envio: {$mail->ErrorInfo}";
            }
            }
        }
        public function igualarC(){
            if(isset($_POST['Token'])){
                $datosC = array();
                $datosC = array('Token' =>$_POST['Token'] );
                $token= $datosC['Token'];
                
                if ($_SESSION['Token'] == $token){
                    header("location: index.php?ruta=cambiarcontraseña");
                }
                else{
                    echo "<script>
                    M.toast({html: 'Token valido'})
                    </script>";
                    
                }
            }
        }
        public function actualizarContraC(){
            if(isset($_POST['emailR'])){
            if($_POST['emailR'] == $_POST['email1R']){
                $datosC =array();
                $pw_temp=($_POST['emailR']);
                $datosC['clave'] = password_hash($pw_temp,PASSWORD_DEFAULT);
                $result = $this->crearusuarioM->actualizarContraM($datosC);
                header('location: index.php?ruta');
                    }
                }
            }
}
?>