<?php  // Controladores/empleadosC.php
class EmpleadosC
{
    function __construct()
    {
        $this->empleadosM = new EmpleadosM();
    }

    // 1. Registrar un nuevo sector (Para el Administrador)
    public function registrarSectorC()
    {
        if (isset($_POST['guardar_sector'])) {
            $datosC = array("nombre_sector" => $_POST['nombre_sector']);
            $this->empleadosM->registrarSectorM($datosC);
            header("location: index.php?ruta=reciclaje");
        }
    }

    // 2. Mostrar la lista de sectores disponibles
    public function mostrarSectoresC()
    {
        return $this->empleadosM->mostrarSectoresM();
    }

    // 3. Registrar los kilos de reciclaje diarios de un sector
    // Actualizar en Controladores/empleadosC.php
    public function registrarReciclajeDiarioC()
    {
        if (isset($_POST['guardar_reciclaje'])) {
            $datosC = array(
                "id_sector" => $_POST['id_sector'],
                "cantidad_kg" => $_POST['cantidad_kg'], // Mantiene el nombre de variable pero ahora recibe M3
                "placa_vehiculo" => $_POST['placa_vehiculo'] // <-- Captura la Placa del Vehículo
            );
            date_default_timezone_set('America/Lima');
            $datosC['fecha'] = date('Y-m-d');

            $this->empleadosM->registrarReciclajeDiarioM($datosC);
            header("location: index.php?ruta=reciclaje");
        }
    }

    // 4. Mostrar el historial general de reciclaje acumulado
    public function mostrarHistorialReciclajeC()
    {
        return $this->empleadosM->mostrarHistorialReciclajeM();
    }

    public function exportarWordAsistentesC()
    {
        // Detecta si se solicita la acción de exportar por URL
        if (isset($_GET['action']) && $_GET['action'] == 'exportarWord' && isset($_GET['id_campania'])) {
            if (session_status() == PHP_SESSION_NONE) {
                session_start();
            }

            // CONTROL DE ACCESO SEGURIDAD: Solo el Responsable (administrador) puede proceder
            if (!isset($_SESSION['rol']) || $_SESSION['rol'] != 'administrador') {
                header('location: index.php?ruta=empleados');
                exit();
            }

            $id_campania = $_GET['id_campania'];
            $infoCampania = $this->empleadosM->mostrarCampaniaIndividualM($id_campania);
            $listaAsistentes = $this->empleadosM->mostrarAsistentesCampaniaM($id_campania);

            $nombreFile = "Lista_Asistentes_Campania_" . $id_campania . ".doc";

            // Configuración de Cabeceras HTTP para forzar la descarga de Word
            header("Content-type: application/vnd.ms-word");
            header("Content-Disposition: attachment; Filename=" . $nombreFile);
            header("Pragma: no-cache");
            header("Expires: 0");

            // Construcción del documento HTML compatible con MS Word
?>
            <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>

            <head>
                <meta charset="utf-8">
                <title>Reporte de Asistentes</title>
                <style>
                    @page Section1 {
                        size: 8.5in 11.0in;
                        /* Tamaño Carta */
                        margin: 1.0in 1.0in 1.0in 1.0in;
                        mso-header-margin: .5in;
                        mso-header: h1;
                        /* ID del elemento que será el encabezado */
                    }

                    div.Section1 {
                        page: Section1;
                    }

                    /* Estilo para el encabezado repetitivo */
                    p.MsoHeader {
                        margin: 0px;
                        text-align: center;
                    }

                    .table-header-word {
                        width: 100%;
                        border-bottom: 2px solid #b71c1c;
                        font-family: Arial, sans-serif;
                        font-size: 10pt;
                        margin-bottom: 20px;
                    }

                    /* Estilos del cuerpo del documento */
                    body {
                        font-family: Arial, sans-serif;
                        font-size: 11pt;
                    }

                    .titulo-doc {
                        text-align: center;
                        color: #b71c1c;
                        font-size: 16pt;
                        font-weight: bold;
                        margin-top: 10px;
                    }

                    .tabla-datos {
                        width: 100%;
                        border-collapse: collapse;
                        margin-top: 15px;
                    }

                    .tabla-datos th {
                        background-color: #b71c1c;
                        color: white;
                        padding: 8px;
                        border: 1px solid #7f0000;
                        font-size: 10pt;
                    }

                    .tabla-datos td {
                        padding: 6px;
                        border: 1px solid #d3d3d3;
                        font-size: 10pt;
                    }
                </style>
            </head>

            <body>
                <div class="Section1">

                    <div style='mso-element:header' id="h1">
                        <p class="MsoHeader">
                        <table class="table-header-word" cellspacing="0" cellpadding="4">
                            <tr>
                                <td style="font-weight:bold; color:#b71c1c; font-size:12pt;" colspan="2">
                                    SISTEMA DE GESTIÓN DE RESIDUOS - FICHA DE ASISTENCIA
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Campaña:</strong> <?php echo $infoCampania['nombre_campania']; ?></td>
                                <td><strong>Lugar:</strong> <?php echo $infoCampania['lugar']; ?></td>
                            </tr>
                            <tr>
                                <td><strong>Fecha:</strong> <?php echo date('d/m/Y', strtotime($infoCampania['fecha'])); ?></td>
                                <td><strong>Tipo de Reunión:</strong> <?php echo $infoCampania['tipo_reunion']; ?></td>
                            </tr>
                        </table>
                        </p>
                    </div>

                    <div class="titulo-doc">PADRÓN COMPLETO DE ASISTENTES REGISTRADOS</div>
                    <br>

                    <table class="tabla-datos">
                        <thead>
                            <tr>
                                <th>N°</th>
                                <th>Nombres y Apellidos</th>
                                <th>DNI</th>
                                <th>Celular</th>
                                <th>Sexo</th>
                                <th>Tipo de Asistente</th>
                                <th>Institución Representada</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $contador = 1;
                            while ($row = mysqli_fetch_array($listaAsistentes)):
                            ?>
                                <tr>
                                    <td style="text-align:center;"><?php echo $contador++; ?></td>
                                    <td><?php echo $row['nombres']; ?></td>
                                    <td style="text-align:center;"><?php echo $row['dni']; ?></td>
                                    <td style="text-align:center;"><?php echo $row['telefono']; ?></td>
                                    <td style="text-align:center;"><?php echo $row['sexo']; ?></td>
                                    <td><?php echo $row['tipo']; ?></td>
                                    <td><?php echo $row['institucion']; ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>

                </div>
            </body>

            </html>
<?php
            exit(); // Interrumpe la renderización para que no se acople la plantilla web dentro del Word
        }
    }





    // Mostrar campañas vigentes (Disponibles para todos)
    public function mostrarCampaniasActivasC()
    {
        $result = $this->empleadosM->mostrarCampaniasActivasM();
        return $result;
    }

    // Mostrar campañas antiguas (Exclusivo para el Administrador)
    public function mostrarCampaniasAntiguasC()
    {
        if ($_SESSION['rol'] == 'administrador') {
            $result = $this->empleadosM->mostrarCampaniasAntiguasM();
            return $result;
        }
        return null;
    }

    public function registrarCampaniaC()
    {
        if (isset($_POST['guardar_campania'])) {
            $datosC = array();
            $datosC['nombre_campania'] = $_POST['nombre_campania'];
            $datosC['fecha'] = $_POST['fecha'];
            $datosC['lugar'] = $_POST['lugar'];
            $datosC['tipo_reunion'] = $_POST['tipo_reunion'];

            $result = $this->empleadosM->registrarCampaniaM($datosC);

            // Al guardar, redireccionamos al menú principal o donde desees
            header('location: index.php?ruta=empleados');
        }
    }

    public function registrarEmpleadosC()
    {
        if (isset($_REQUEST['guardar'])) {
            $datosC = array();
            $tipo_entidad = $_POST['tipo_entidad'];

            $datosC['nombres'] = $_POST['nombres'];
            $datosC['sexo'] = $_POST['sexo'];
            $datosC['dni'] = $_POST['dni'];
            $datosC['telefono'] = $_POST['telefono'];
            $datosC['id_campania'] = $_POST['id_campania']; // <-- Recibe la vinculación

            date_default_timezone_set('America/Lima');
            $datosC['fecha'] = date('Y-m-d');

            if ($tipo_entidad === 'Ciudadano') {
                $result = $this->empleadosM->registrarFichaCiudadanoM($datosC);
            } else if ($tipo_entidad === 'Institución') {
                $datosC['nombre_institucion'] = $_POST['nombre_institucion'];
                $result = $this->empleadosM->registrarFichaInstitucionM($datosC);
            }

            header('location: index.php?ruta=empleados');
        }
    }
    // Nuevo método para llamar los datos de una campaña específica
    public function mostrarCampaniaIndividualC($id_campania)
    {
        $result = $this->empleadosM->mostrarCampaniaIndividualM($id_campania);
        return $result;
    }

    //mostrar empleados
    public function mostrarEmpleadosC()
    {
        $result = $this->empleadosM->mostrarEmpleadosM();
        return $result;
    }
    //mostrar empleados
    public function mostrarEmpleadosArchivadosC()
    {
        $result = $this->empleadosM->mostrarEmpleadosArchivadosM();
        return $result;
    }
    public function mostrarEmpleadosFavoritosC()
    {
        $result = $this->empleadosM->mostrarEmpleadosFavoritosM();
        return $result;
    }

    public function mostrarFiltroEmpleadosC()
    {
        if (isset($_REQUEST['Ram'])) {
            if (isset($_POST['FechaI']) && isset($_POST['FechaF'])) {
                $datosC = array(
                    'FechaI' => $_POST['FechaI'],
                    'FechaF' => $_POST['FechaF'],
                );
                $result = $this->empleadosM->mostrarFiltroEmpleadosM($datosC);
                return $result;
            }
        }
    }
    public function mostrarFiltroPalabraC()
    {
        if (isset($_REQUEST['Rem'])) {
            $datosC = array('Palabra' => $_POST['Palabra']);
            $result = $this->empleadosM->mostrarFiltroPalabraM($datosC);
            $numer0 = mysqli_num_rows($result);
            if ($numer0 == 0) {
                echo "<script>
                M.toast({html: 'No se encontraron resultados'})
                </script>";
            } else {
                return $result;
            }
        }
    }

    //editar empleados
    public function editarEmpleadoC()
    {
        if (isset($_GET['IDDatos'])) {
            $datosC = array('IDDatos' => $_GET['IDDatos']);
            $result = $this->empleadosM->editarEmpleadoM($datosC);
            return $result;
        }
    }

    //actualizar empleados
    public function actualizarEmpleadoC()
    {
        if (isset($_REQUEST['actualisar'])) {
            if (file_exists($_FILES['fotosE']['tmp_name'])) {
                switch ($_FILES['fotosE']['type']) {
                    case 'image/jpeg':
                        $ext = 'jpg';
                        break;
                    case 'image/gif':
                        $ext = 'jpg';
                        break;
                    case 'image/png':
                        $ext = 'png';
                        break;
                    case 'image/tiff':
                        $ext = 'tif';
                        break;
                    default:
                        $ext = '';
                        break;
                }
                if ($ext) {
                    $nombreArchivo = $_FILES['fotosE']['name'];
                    $tamanoArchivo = $_FILES['fotosE']['size'];
                    $imagenSubida = fopen($_FILES['fotosE']['tmp_name'], 'r');
                    $binariosImagen = fread($imagenSubida, $tamanoArchivo);
                } else {
                    echo "<script>
                    M.toast({html: 'Ingrese una imagen valida'})
                    </script>";
                    return ('location: index.php?ruta=registrar');
                }
                $datosC = array(
                    'IDDatos' => $_POST['idE'],
                    'titulo' => $_POST['tituloE'],
                    'Contenido' => $_POST['ContenidosE'],
                    'fecha' => $_POST['fechaE'],
                    'foto' => $binariosImagen
                );
            } else {
                $datosC = array(
                    'IDDatos' => $_POST['idE'],
                    'titulo' => $_POST['tituloE'],
                    'Contenido' => $_POST['ContenidosE'],
                    'fecha' => $_POST['fechaE']
                );
            }

            $result = $this->empleadosM->actualizarEmpleadoM($datosC);
            header('location: index.php?ruta=empleados');
        }
    }

    //borrar empleado
    public function borrarEmpleadoC()
    {
        if (isset($_GET['IDDatos'])) {
            $datosC = array('IDDatos' => $_GET['IDDatos']);
            $tablaBD = 'datos';
            $this->empleadosM->borrarEmpleadoM($datosC, $tablaBD);
            header('location: index.php?rutas=empleados');
        }
    }
    public function favoritoEmpleadoC()
    {
        if (isset($_GET['IDDatos2'])) {
            $datosC = array('IDDatos' => $_GET['IDDatos2']);
            $result = $this->empleadosM->favoritoEmpleadoM($datosC);
            header('location: index.php?ruta=Favoritos');
        }
    }
    public function QfavoritoEmpleadoC()
    {
        if (isset($_GET['IDDatos1'])) {
            $datosC = array('IDDatos' => $_GET['IDDatos1']);
            $result = $this->empleadosM->QfavoritoEmpleadoM($datosC);
            header('location: index.php?rutas=empleados');
        }
    }
    public function ArchivarEmpleadoC()
    {
        if (isset($_GET['IDDatos0'])) {
            $datosC = array('IDDatos' => $_GET['IDDatos0']);
            $result = $this->empleadosM->ArchivarEmpleadoM($datosC);
            header('location: index.php?ruta=Archivados');
        }
    }
}
